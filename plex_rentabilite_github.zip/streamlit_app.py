import streamlit as st
import pandas as pd

st.set_page_config(page_title="Analyse Plex Québec", layout="wide")
st.title("📊 Analyse de rentabilité - Plex à Québec")

st.markdown("Ce dashboard affiche les annonces de plex scrappées localement sur ton Raspberry Pi.")

try:
    df = pd.read_csv("data/annonces.csv")
    st.subheader("📈 Données actuelles")
    st.dataframe(df)
except FileNotFoundError:
    st.warning("⚠️ Aucune donnée trouvée. Téléverse un fichier annonces.csv dans le repo GitHub.")
